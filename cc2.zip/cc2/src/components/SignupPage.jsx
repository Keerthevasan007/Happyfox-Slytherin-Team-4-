import React, { useState } from 'react';

const SignupPage = ({ onSignupSuccess }) => {
  const [formData, setFormData] = useState({ 
    name: '', 
    email: '', 
    password: '', 
    year_of_study: '', 
    department: '',
    bio: '' 
  });
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const { name, email, password, year_of_study, department } = formData;
    if (!name || !email || !password || !year_of_study || !department) {
      setError('Please fill in all required fields');
      return;
    }
    
    try {
      const response = await fetch('/api/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      
      const data = await response.json();
      
      if (response.ok) {
        setSuccess('Registration successful! You can now log in.');
        setFormData({ 
          name: '', 
          email: '', 
          password: '', 
          year_of_study: '', 
          department: '',
          bio: '' 
        });
        
        // If you have a callback function to handle successful signup
        if (onSignupSuccess) {
          onSignupSuccess(data);
        }
      } else {
        setError(data.message || 'Error signing up');
      }
    } catch (err) {
      console.error('Signup error:', err);
      setError('Error connecting to server');
    }
  };

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: 'white',
        padding: '2rem'
      }}
    >
      {/* Left side: Signup Form */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}
      >
        <div
          style={{
            width: '400px',
            backgroundColor: 'white',
            padding: '2rem',
            borderRadius: '0.5rem',
            boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
          }}
        >
          <h2 style={{ textAlign: 'center', marginBottom: '1rem', color: 'black' }}>
            Sign Up
          </h2>
          
          {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
          {success && <p style={{ color: 'green', textAlign: 'center' }}>{success}</p>}
          
          <form onSubmit={handleSubmit}>
            <input
              type="text"
              name="name"
              placeholder="Full Name"
              value={formData.name}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: 'black'
              }}
              required
            />
            
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: 'black'
              }}
              required
            />
            
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: 'black'
              }}
              required
            />
            
            <input
              type="text"
              name="year_of_study"
              placeholder="Year of Study (e.g., 3)"
              value={formData.year_of_study}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: 'black'
              }}
              required
            />
            
            <input
              type="text"
              name="department"
              placeholder="Department (e.g., Computer Science)"
              value={formData.department}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: 'black'
              }}
              required
            />
            
            <textarea
              name="bio"
              placeholder="Bio (optional)"
              value={formData.bio}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: 'black',
                minHeight: '100px',
                resize: 'vertical'
              }}
            />
            
            <button
              type="submit"
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                backgroundColor: '#2563eb',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                cursor: 'pointer',
                fontSize: '1rem'
              }}
            >
              Sign Up
            </button>
          </form>
        </div>
      </div>

      {/* Right side: Branding */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'flex-end',
          padding: '2rem'
        }}
      >
        <h1 style={{ fontSize: '3rem', fontWeight: 'bold', margin: 0, color: 'black' }}>
          Campus Connect
        </h1>
        <p style={{ fontSize: '1.25rem', margin: '0.5rem 0 0 0', color: 'black' }}>
          Join our community and connect with students!
        </p>
      </div>
    </div>
  );
};

export default SignupPage;