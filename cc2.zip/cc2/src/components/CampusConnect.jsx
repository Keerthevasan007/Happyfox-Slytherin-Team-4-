import React, { useState } from 'react';
import { Calendar, Search, Grid, Users, MapPin, ChevronRight } from 'lucide-react';

const CampusConnect = ({ user }) => {
  const [isMainPageOpen, setIsMainPageOpen] = useState(false);
  const [popupMessage, setPopupMessage] = useState(null);
  const [showCreateEventModal, setShowCreateEventModal] = useState(false);

  const [upcomingEvents, setUpcomingEvents] = useState([
    { id: 1, name: "Tech Symposium 2025", date: "2025-03-15", participants: 120, location: "Main Auditorium" },
    { id: 2, name: "Career Fair", date: "2025-03-20", participants: 500, location: "Campus Ground" },
    { id: 3, name: "Coding Workshop", date: "2025-03-25", participants: 50, location: "Lab 101" }
  ]);

  const [eventName, setEventName] = useState('');
  const [eventDate, setEventDate] = useState('');
  const [eventLocation, setEventLocation] = useState('');
  const [eventParticipants, setEventParticipants] = useState('');

  const formatDate = (dateString) => {
    const options = { year: 'numeric', month: 'short', day: 'numeric' };
    return new Date(dateString).toLocaleDateString(undefined, options);
  };

  const handleCreateEvent = () => {
    setShowCreateEventModal(true);
  };

  const handleCreateEventSubmit = async (e) => {
    e.preventDefault();
    const eventData = {
      name: eventName,
      date: eventDate,
      location: eventLocation,
      participants: parseInt(eventParticipants, 10)
    };

    try {
      const response = await fetch('/api/events', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(eventData)
      });
      const data = await response.json();
      if (response.ok) {
        const newEvent = { 
          id: data.eventId || upcomingEvents.length + 1, 
          name: eventName, 
          date: eventDate, 
          location: eventLocation, 
          participants: parseInt(eventParticipants, 10) 
        };
        setUpcomingEvents([...upcomingEvents, newEvent]);
        setPopupMessage(`Event created: ${eventName}`);
        setShowCreateEventModal(false);
        setEventName(''); 
        setEventDate('');
        setEventLocation('');
        setEventParticipants('');
      } else {
        setPopupMessage(data.message || 'Error creating event');
      }
    } catch (error) {
      console.error('Error:', error);
      setPopupMessage('Error connecting to server');
    }
  };

  const handleJoinEvent = async (eventId) => {
    try {
      if (!eventId || !user?.email) {
        setPopupMessage('Missing event ID or user email');
        return;
      }

      const response = await fetch('/api/join-event', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({
          event_id: eventId,
          user_email: user?.email
        })
      });

      const data = await response.json();

      if (response.ok) {
        setPopupMessage('Successfully joined event!');
        setUpcomingEvents(prevEvents =>
          prevEvents.map(e =>
            e.id === eventId 
              ? { ...e, participants: e.participants + 1 } 
              : e
          )
        );
      } else {
        setPopupMessage(data.message || 'Failed to join event');
      }
    } catch (error) {
      console.error('Error:', error);
      setPopupMessage('Error connecting to server');
    }
  };

  const handleEventsClick = () => {
    console.log("Events sidebar clicked");
  };

  const handleSearchChange = (e) => {
    console.log("Search query:", e.target.value);
  };

  const IconLauncher = () => (
    <button
      onClick={() => setIsMainPageOpen(true)}
      className="p-2 bg-blue-500 text-white rounded-md"
    >
      <Grid size={24} />
    </button>
  );

  const EventCard = ({ event }) => (
    <div className="p-4 bg-white shadow-md rounded-lg mb-4">
      <h2 className="text-xl font-bold text-gray-800">{event.name}</h2>
      <p className="text-gray-700">{formatDate(event.date)}</p>
      <p className="text-gray-700">{event.location}</p>
      <p className="text-gray-700 mb-3">{event.participants} participants</p>
      <button
        onClick={() => handleJoinEvent(event.id)}
        className="w-full py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center justify-center"
      >
        Join Event
      </button>
    </div>
  );

  const MainDashboard = () => (
    <div className="fixed inset-0 z-50 bg-white overflow-auto">
      <div className="flex h-screen">
        <div className="w-64 bg-blue-600 text-white p-4">
          <div className="flex items-center justify-between mb-8">
            <h1 className="text-2xl font-bold">Campus Connect</h1>
            <button 
              onClick={() => setIsMainPageOpen(false)}
              className="p-1 bg-blue-500 text-white rounded-full hover:bg-blue-700"
            >
              &times;
            </button>
          </div>
          <nav className="space-y-4">
            <button 
              onClick={handleEventsClick} 
              className="w-full py-2 bg-blue-500 text-white rounded-md hover:bg-blue-700 transition-colors flex items-center justify-between"
            >
              <div className="flex items-center">
                <Calendar size={20} className="mr-2 text-black" />
                Events
              </div>
              <ChevronRight size={16} />
            </button>
          </nav>
        </div>
        <div className="flex-1 p-6 overflow-auto bg-gray-50">
          <div className="mb-8">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-2xl font-bold text-gray-800">Upcoming Events</h2>
              <button 
                onClick={handleCreateEvent} 
                className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
              >
                Create Event
              </button>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {upcomingEvents.map(event => (
                <EventCard key={event.id} event={event} />
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );

  return (
    <div>
      {!isMainPageOpen ? (
        <IconLauncher />
      ) : (
        <MainDashboard />
      )}

      {popupMessage && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg max-w-md w-full">
            <p className="text-xl text-gray-800 mb-4">{popupMessage}</p>
            <button
              onClick={() => setPopupMessage(null)}
              className="w-full px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              Close
            </button>
          </div>
        </div>
      )}

      {showCreateEventModal && (
        <div className="fixed inset-0 flex items-center justify-center z-50 bg-black bg-opacity-50">
          <div className="bg-white w-full max-w-md p-6 rounded-lg shadow-lg">
            <h2 className="text-2xl font-bold mb-4 text-gray-800">Create New Event</h2>
            <form onSubmit={handleCreateEventSubmit}>
              <div className="mb-4">
                <label htmlFor="eventName" className="block mb-2 text-gray-700">Event Name</label>
                <input
                  type="text"
                  id="eventName"
                  value={eventName}
                  onChange={(e) => setEventName(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="eventDate" className="block mb-2 text-gray-700">Date</label>
                <input
                  type="date"
                  id="eventDate"
                  value={eventDate}
                  onChange={(e) => setEventDate(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="eventLocation" className="block mb-2 text-gray-700">Location</label>
                <input
                  type="text"
                  id="eventLocation"
                  value={eventLocation}
                  onChange={(e) => setEventLocation(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                  required
                />
              </div>
              <div className="mb-4">
                <label htmlFor="eventParticipants" className="block mb-2 text-gray-700">Expected Participants</label>
                <input
                  type="number"
                  id="eventParticipants"
                  value={eventParticipants}
                  onChange={(e) => setEventParticipants(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 bg-white text-gray-800"
                  required
                />
              </div>
              <div className="flex justify-between gap-4">
                <button
                  type="button"
                  onClick={() => setShowCreateEventModal(false)}
                  className="px-4 py-2 bg-gray-200 text-gray-800 rounded-md hover:bg-gray-300 transition-colors flex-1"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors flex-1"
                >
                  Create Event
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};

export default CampusConnect;