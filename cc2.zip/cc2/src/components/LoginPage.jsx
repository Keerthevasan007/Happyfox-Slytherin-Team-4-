import React, { useState } from 'react';

const LoginPage = ({ onLoginSuccess, onSwitchToSignup }) => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const handleInputChange = (e) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
    setError('');
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!(formData.email && formData.password)) {
      setError('Please fill in both fields');
      return;
    }

    try {
      const response = await fetch('/api/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });
      
      const data = await response.json();
      
      if (response.ok) {
        onLoginSuccess(data.user);
      } else {
        setError(data.message || 'Invalid credentials');
      }
    } catch (err) {
      console.error('Error during login:', err);
      setError('Error connecting to server');
    }
  };

  return (
    <div
      style={{
        display: 'flex',
        alignItems: 'center',
        minHeight: '100vh',
        backgroundColor: '#f3f4f6',
        padding: '2rem'
      }}
    >
      {/* Login Form */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          justifyContent: 'center',
          alignItems: 'center'
        }}
      >
        <div
          style={{
            width: '400px',
            backgroundColor: 'white',
            padding: '2rem',
            borderRadius: '0.5rem',
            boxShadow: '0 1px 3px rgba(0,0,0,0.1)'
          }}
        >
          <h2 style={{ textAlign: 'center', marginBottom: '1rem', color: '#333' }}>
            Login
          </h2>
          {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
          <form onSubmit={handleSubmit}>
            <input
              type="email"
              name="email"
              placeholder="Email Address"
              value={formData.email}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: '#333',
                backgroundColor: 'white'
              }}
              required
            />
            <input
              type="password"
              name="password"
              placeholder="Password"
              value={formData.password}
              onChange={handleInputChange}
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                marginBottom: '1rem',
                borderRadius: '0.5rem',
                border: '1px solid #e5e7eb',
                color: '#333',
                backgroundColor: 'white'
              }}
              required
            />
            <button
              type="submit"
              style={{
                width: '100%',
                padding: '0.75rem 1rem',
                backgroundColor: '#2563eb',
                color: 'white',
                border: 'none',
                borderRadius: '0.5rem',
                cursor: 'pointer',
                fontSize: '1rem'
              }}
            >
              Login
            </button>
          </form>
          <p style={{ marginTop: '1rem', textAlign: 'center', color: '#333' }}>
            Don't have an account?{' '}
            <button
              onClick={onSwitchToSignup}
              style={{
                background: 'none',
                border: 'none',
                color: '#2563eb',
                cursor: 'pointer',
                textDecoration: 'underline'
              }}
            >
              Sign Up
            </button>
          </p>
        </div>
      </div>

      {/* Right side: Website Name */}
      <div
        style={{
          flex: 1,
          display: 'flex',
          flexDirection: 'column',
          justifyContent: 'center',
          alignItems: 'flex-end',
          padding: '2rem'
        }}
      >
        <h1 style={{ fontSize: '3rem', fontWeight: 'bold', margin: 0, color: '#333' }}>
          Campus Connect
        </h1>
        <p style={{ fontSize: '1.25rem', margin: '0.5rem 0 0 0', color: '#333' }}>
          Connect with Students around the college
        </p>
      </div>
    </div>
  );
};

export default LoginPage;