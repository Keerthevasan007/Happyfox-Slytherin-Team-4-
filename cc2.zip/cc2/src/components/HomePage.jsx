import React, { useState, useEffect } from 'react';
import { Search, Bell, MessageSquare } from 'lucide-react';

const HomePage = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);
  const [selectedUser, setSelectedUser] = useState(null);
  const [currentUser, setCurrentUser] = useState(null);

  useEffect(() => {
    // Fetch current user's details
    const fetchCurrentUser = async () => {
      try {
        const response = await fetch('/api/current-user');
        const data = await response.json();
        setCurrentUser(data);
      } catch (error) {
        console.error('Error fetching current user:', error);
      }
    };

    fetchCurrentUser();
  }, []);

  const handleSearch = async (e) => {
    const query = e.target.value;
    setSearchQuery(query);

    if (query.length > 2) {
      try {
        const response = await fetch(`/api/search-users?q=${query}`);
        const data = await response.json();
        setSearchResults(data);
      } catch (error) {
        console.error('Error searching users:', error);
      }
    } else {
      setSearchResults([]);
    }
  };

  const handleUserClick = (user) => {
    setSelectedUser(user);
    setSearchResults([]);
    setSearchQuery('');
  };

  return (
    <div className="min-h-screen bg-blue-50">
      {/* Header */}
      <header className="bg-blue-600 shadow-lg">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-8">
              <h1 className="text-2xl font-bold text-white">CampusConnect</h1>
              <div className="relative">
                <input
                  type="text"
                  placeholder="Search students..."
                  value={searchQuery}
                  onChange={handleSearch}
                  className="w-96 pl-10 pr-4 py-2 rounded-full border-2 border-blue-400 focus:outline-none focus:border-white bg-blue-500 text-white placeholder-blue-200"
                />
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-blue-200" size={20} />
                
                {searchResults.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-2 bg-white rounded-lg shadow-xl z-50">
                    {searchResults.map(user => (
                      <div
                        key={user.id}
                        onClick={() => handleUserClick(user)}
                        className="flex items-center gap-3 p-3 hover:bg-blue-50 cursor-pointer border-b border-blue-100 last:border-b-0"
                      >
                        <img
                          src={user.photo_url || "/api/placeholder/40/40"}
                          alt={user.name}
                          className="w-10 h-10 rounded-full border-2 border-blue-200"
                        />
                        <div>
                          <p className="font-medium text-blue-900">{user.name}</p>
                          <p className="text-sm text-blue-600">{user.major}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            </div>
            
            <div className="flex items-center gap-6">
              <Bell className="text-white cursor-pointer hover:text-blue-200" size={24} />
              <MessageSquare className="text-white cursor-pointer hover:text-blue-200" size={24} />
              <img
                src={currentUser?.photo_url || "/api/placeholder/40/40"}
                alt="Profile"
                onClick={() => handleUserClick(currentUser)}
                className="w-10 h-10 rounded-full cursor-pointer border-2 border-white hover:border-blue-200"
              />
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {selectedUser ? (
          <ProfilePage
            user={selectedUser}
            onBack={() => setSelectedUser(null)}
          />
        ) : (
          <div className="grid grid-cols-3 gap-8">
            {/* Profile Summary */}
            <div className="bg-white rounded-lg shadow-lg hover:shadow-xl transition-shadow">
              <div className="bg-blue-600 rounded-t-lg p-4">
                <div className="text-center">
                  <img
                    src={currentUser?.photo_url || "/api/placeholder/128/128"}
                    alt="Profile"
                    className="w-32 h-32 rounded-full mx-auto border-4 border-white"
                  />
                </div>
              </div>
              <div className="p-6">
                <h2 className="text-xl font-bold text-blue-900 text-center">{currentUser?.name}</h2>
                <p className="text-blue-600 text-center">{currentUser?.major}</p>
              </div>
            </div>

            {/* Feed Section */}
            <div className="col-span-2 bg-white rounded-lg shadow-lg p-6">
              <h2 className="text-xl font-bold text-blue-900 mb-6">Activity Feed</h2>
              <div className="space-y-4">
                {/* Example feed items */}
                <div className="p-4 border border-blue-100 rounded-lg hover:bg-blue-50">
                  <p className="text-blue-900">Sample activity feed item</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
};

export default HomePage;