import React, { useState, useEffect } from 'react';
import { Search, Users, Bell, MessageSquare, Grid, User } from 'lucide-react';
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card, CardHeader, CardTitle, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

const SocialDashboard = ({ user, onProfileClick }) => {
  // Posts states
  const [posts, setPosts] = useState([]);
  const [currentUser, setCurrentUser] = useState(user);
  const [popupMessage, setPopupMessage] = useState('');
  const [newPostText, setNewPostText] = useState('');
  const [newPostImage, setNewPostImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [showAddPostModal, setShowAddPostModal] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  // Search states (for posts area)
  const [searchQuery, setSearchQuery] = useState('');
  const [searchResults, setSearchResults] = useState([]);

  // Comments and likes
  const [comments, setComments] = useState({});
  const [newComments, setNewComments] = useState({});
  const [showComments, setShowComments] = useState({});

  // Connection requests
  const [connectionRequests, setConnectionRequests] = useState({});

  // Debug logs to check user data
  useEffect(() => {
    console.log("Current user in SocialDashboard:", currentUser);
  }, [currentUser]);

  useEffect(() => {
    // Call the fetchPosts function when component mounts
    fetchPosts();
    
    // For development purposes, let's add a console log to see what posts 
    // are being displayed
    console.log("Initial posts state:", posts);
  }, []);

  // Function to load Voiceflow chat widget
  useEffect(() => {
    const loadVoiceflowWidget = () => {
      const script = document.createElement('script');
      script.type = 'text/javascript';
      script.onload = function() {
        window.voiceflow.chat.load({
          verify: { projectID: '67bcb3759ecb13d4c9cb38e1' },
          url: 'https://general-runtime.voiceflow.com',
          versionID: 'production', 
          voice: { 
            url: "https://runtime-api.voiceflow.com" 
          }
        });
      };
      script.src = "https://cdn.voiceflow.com/widget-next/bundle.mjs";
      document.body.appendChild(script);
    };

    loadVoiceflowWidget();

    // Cleanup function to remove the script when component unmounts
    return () => {
      const scriptElements = document.querySelectorAll('script[src="https://cdn.voiceflow.com/widget-next/bundle.mjs"]');
      scriptElements.forEach(element => element.remove());
    };
  }, []);

  // Function to fetch posts from the backend
  // Replace the useEffect mock data with this code

// Make sure fetchPosts actually makes the API call instead of using mock data
  const fetchPosts = async () => {
    try {
      const response = await fetch('/api/posts');
      if (response.ok) {
        const data = await response.json();
        
        // Process the posts to ensure image URLs are correct
        const processedPosts = data.map(post => {
          if (post.imageUrl) {
            // Make sure imageUrl is properly formed
            if (!post.imageUrl.startsWith('/') && !post.imageUrl.startsWith('http')) {
              post.imageUrl = `/${post.imageUrl}`;
            }
          }
          return post;
        });
        
        setPosts(processedPosts);
        console.log("Processed posts:", processedPosts); // Debug log
      } else {
        console.error('Error fetching posts:', response.statusText);
      }
    } catch (error) {
      console.error('Error fetching posts:', error);
      // Your mock data fallback...
    }
  };


  // Function to fetch users from the backend
  const fetchUsers = async (query) => {
    try {
      const response = await fetch(`/api/users?query=${query}`);
      if (response.ok) {
        const data = await response.json();
        setSearchResults(data);
      }
    } catch (error) {
      console.error('Error fetching users:', error);
      // Mock data for demo purposes
      setSearchResults([
        { id: 101, name: "Jane Doe", role: "Student" },
        { id: 102, name: "John Smith", role: "Professor" }
      ]);
    }
  };

  

  // Simulated data fetching on mount (if needed)
  useEffect(() => {
    // For now, use example data; you can replace with fetchPosts() when ready
    setPosts([
      {
        id: 1,
        author: "Alice Smith",
        content: "Just finished my research project on AI!",
        timestamp: "2 hours ago",
        likes: 15,
        imageUrl: null,
        liked: false
      },
      {
        id: 2,
        author: "Bob Johnson",
        content: "Looking for study partners for upcoming finals",
        timestamp: "5 hours ago",
        likes: 8,
        imageUrl: null,
        liked: false
      }
    ]);
    setComments({
      1: [
        { id: 1, author: "Jane Doe", content: "Congrats on finishing your project!", timestamp: "1 hour ago" },
        { id: 2, author: "Mike Wilson", content: "I'd love to see your results!", timestamp: "30 mins ago" }
      ],
      2: [
        { id: 1, author: "Sarah Lee", content: "I'm available on Tuesdays and Thursdays", timestamp: "4 hours ago" }
      ]
    });
    setNewComments({ 1: '', 2: '' });

    // If current user is not set, set a default user for testing
    if (!currentUser) {
      setCurrentUser({
        id: 1, // Make sure this matches an existing user ID in your database
        name: "Current User",
        email: "user@example.com"
      });
    }
  }, []);

  const handleCommentChange = (postId, value) => {
    setNewComments(prev => ({ ...prev, [postId]: value }));
  };

  const handleImageChange = (e) => {
    const file = e.target.files[0];
    if (file) {
      setNewPostImage(file);
      // Create a preview URL for the image
      const reader = new FileReader();
      reader.onload = () => {
        setImagePreview(reader.result);
      };
      reader.readAsDataURL(file);
    }
  };

  // Function to handle post submission
  const handlePostSubmit = async (e) => {
    e.preventDefault();
    
    if (!newPostText.trim()) {
      setPopupMessage('Please enter some content for your post');
      return;
    } 
    
    setIsLoading(true);
    
    try {
      let imageUrl = null;
      
      // If there's an image, first upload it to the server
      if (newPostImage) {
        const formData = new FormData();
        formData.append('image', newPostImage);
        
        const imageResponse = await fetch('/api/upload-image', {
          method: 'POST',
          body: formData,
        });
        
        if (imageResponse.ok) {
          const imageData = await imageResponse.json();
          imageUrl = imageData.imageUrl;
          console.log("Uploaded image URL:", imageUrl); // Debug log to see the received URL
        } else {
          throw new Error('Failed to upload image');
        }
      }
      
      // Create post payload
      const postData = {
        user_email: currentUser.email,
        content: newPostText,
        image: imageUrl // This should be just the URL
      };
      console.log("Sending post data:", postData); // Debug log to see what's being sent
      
      // Call API to create post
      const response = await fetch('/api/create-post', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json'
        },
        body: JSON.stringify(postData)
      });
      
      if (response.ok) {
        // Post created successfully, refresh posts
        await fetchPosts(); // Make sure to await this
        setNewPostText('');
        setNewPostImage(null);
        setImagePreview(null);
        setShowAddPostModal(false);
        setPopupMessage('Post created successfully!');
      } else {
        const errorData = await response.json();
        setPopupMessage(`Error creating post: ${errorData.message}`);
      }
    } catch (error) {
      console.error('Error creating post:', error);
      setPopupMessage(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleSearch = (e) => {
    const query = e.target.value;
    setSearchQuery(query);
    if (query.length > 0) {
      fetchUsers(query);
    } else {
      setSearchResults([]);
    }
  };

  const handleSearchKeyPress = (e) => {
    if (e.key === 'Enter') {
      handleSearch(e);
    }
  };

  const handleProfileIconClick = () => {
    // Check if currentUser exists and has an id
    if (!currentUser || !currentUser.id) {
      console.error("Cannot navigate to profile: currentUser or currentUser.id is undefined");
      setPopupMessage("User profile information is not available");
      return;
    }
    
    console.log("Profile clicked, passing userId:", currentUser.id);
    onProfileClick(currentUser.id);
  };

  // Function to handle like button click
  const handleLikeClick = (postId) => {
    setPosts(posts.map(post => 
      post.id === postId ? { ...post, liked: !post.liked, likes: post.liked ? post.likes - 1 : post.likes + 1 } : post
    ));
  };

  // Function to handle comment button click
  const handleCommentClick = (postId) => {
    setShowComments(prev => ({ ...prev, [postId]: !prev[postId] }));
  };

  // Function to handle posting a comment
  const handlePostComment = (postId) => {
    const commentContent = newComments[postId];
    if (commentContent.trim()) {
      setComments(prevComments => ({
        ...prevComments,
        [postId]: [
          ...(prevComments[postId] || []),
          {
            id: Date.now(),
            author: currentUser.name,
            content: commentContent,
            timestamp: 'Just now'
          }
        ]
      }));
      setNewComments(prev => ({ ...prev, [postId]: '' }));
    }
  };

  // Function to handle sending a connection request
  const handleSendConnectionRequest = async (userId) => {
    if (!connectionRequests[userId]) {
      try {
        // Simulate API call for demo
        setConnectionRequests(prev => ({ ...prev, [userId]: true }));
        setPopupMessage('Connection request sent');
      } catch (error) {
        console.error('Error sending connection request:', error);
        setPopupMessage('Error sending connection request');
      }
    } else {
      setPopupMessage('Connection request already sent');
    }
  };

  // Function to handle accepting a connection request (to be implemented in the backend)
  const handleAcceptConnectionRequest = async (userId) => {
    try {
      // Simulate API call for demo
      setPopupMessage('Connection request accepted');
    } catch (error) {
      console.error('Error accepting connection request:', error);
      setPopupMessage('Error accepting connection request');
    }
  };

  return (
    <div>
      {/* Header */}
      <header className="flex items-center justify-between p-4 bg-white shadow-md">
        <h1 className="text-2xl font-bold">Campus Social</h1>
        <div className="flex items-center space-x-4">
          <Input
            type="text"
            placeholder="Search..."
            value={searchQuery}
            onChange={handleSearch}
            onKeyPress={handleSearchKeyPress}
          />
          <Button onClick={() => setShowAddPostModal(true)} className="px-6 py-2 bg-blue-600 text-white rounded-full">
            Add Post
          </Button>
          <Avatar onClick={handleProfileIconClick} className="cursor-pointer">
            <AvatarFallback>{currentUser?.name?.[0]}</AvatarFallback>
          </Avatar>
        </div>
      </header>

      {/* Search Results */}
      {searchResults.length > 0 && (
        <div className="p-4 bg-white shadow-md">
          {searchResults.map(user => (
            <div key={user.id} className="flex items-center space-x-2 mb-2">
              <Avatar>
                <AvatarFallback>{user.name[0]}</AvatarFallback>
              </Avatar>
              <div>
                <p>{user.name}</p>
                <p>{user.role}</p>
              </div>
              <Button onClick={() => handleSendConnectionRequest(user.id)} className="bg-white text-black">
                {connectionRequests[user.id] ? 'Request Sent' : 'Connect'}
              </Button>
            </div>
          ))}
        </div>
      )}

      {/* Main content */}
      <main className="p-4">
        {posts.map(post => (
          <Card key={post.id}>
            <CardHeader>
              <div className="flex items-center space-x-2">
                <Avatar>
                  <AvatarFallback>{post.author[0]}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle>{post.author}</CardTitle>
                  <p>{post.timestamp}</p>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              <p>{post.content}</p>
              {post.imageUrl && <img src={post.imageUrl} alt="Post" />}
              <div className="flex items-center space-x-2 mt-2">
                <img 
                  src ={post.imageUrl}
                  alt='Post'
                  className='w-full h-auto object-cover'
                  onError={(e) => {
                    console.error('Error loading image: ${post.imageUrl}');
                    e.target.style.display = 'none';
                  } }
                  />
                <Button onClick={() => handleLikeClick(post.id)} className={`bg-white text-black ${post.liked ? "text-blue-600" : ""}`}>
                  👍 {post.likes}
                </Button>
                <Button onClick={() => handleCommentClick(post.id)} className="bg-white text-black">
                  💬 Comment
                </Button>
              </div>
              {showComments[post.id] && (
                <div className="mt-2">
                  {comments[post.id] && comments[post.id].length > 0 && (
                    <div>
                      {comments[post.id].map(comment => (
                        <div key={comment.id} className="flex items-center space-x-2 mb-2">
                          <Avatar>
                            <AvatarFallback>{comment.author[0]}</AvatarFallback>
                          </Avatar>
                          <div>
                            <p>{comment.author}</p>
                            <p>{comment.content}</p>
                            <p>{comment.timestamp}</p>
                          </div>
                        </div>
                      ))}
                    </div>
                  )}
                  <div className="flex items-center space-x-2 mt-2">
                    <Input
                      type="text"
                      placeholder="Write a comment..."
                      value={newComments[post.id]}
                      onChange={(e) => handleCommentChange(post.id, e.target.value)}
                      className="flex-1 bg-white text-black"
                    />
                    <Button onClick={() => handlePostComment(post.id)} className="ml-2 bg-white text-black">
                      Post
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </main>

      {/* Suggested Connections */}
      <section className="p-4">
        <h2>Suggested Connections</h2>
        <div className="grid grid-cols-3 gap-4">
          {[1, 2, 3].map(i => (
            <div key={i} className="flex items-center space-x-2">
              <Avatar>
                <AvatarFallback>U</AvatarFallback>
              </Avatar>
              <div>
                <p>User {i}</p>
                <p>Student</p>
              </div>
              <Button onClick={() => handleSendConnectionRequest(i)} className="bg-white text-black">
                {connectionRequests[i] ? 'Request Sent' : 'Connect'}
              </Button>
            </div>
          ))}
        </div>
      </section>

      {/* Full-Screen Modal for Adding a Post */}
      {showAddPostModal && (
        <div className="fixed inset-0 flex items-center justify-center bg-black bg-opacity-50 z-50">
          <div className="bg-white p-6 rounded-lg shadow-lg w-full max-w-md">
            <h2>Create New Post</h2>
            <form onSubmit={handlePostSubmit}>
              <Input
                type="text"
                placeholder="What's on your mind?"
                value={newPostText}
                onChange={(e) => setNewPostText(e.target.value)}
                required
              />
              <Input
                type="file"
                accept="image/*"
                onChange={handleImageChange}
                id="image-upload"
                className="mt-2"
              />
              {imagePreview && (
                <div className="mt-2">
                  <p>Image Preview:</p>
                  <img src={imagePreview} alt="Preview" className="w-full" />
                  <Button
                    onClick={() => {
                      setNewPostImage(null);
                      setImagePreview(null);
                      document.getElementById('image-upload').value = '';
                    }}
                    className="mt-2"
                  >
                    Remove Image
                  </Button>
                </div>
              )}
              <div className="flex justify-end mt-4">
                <Button
                  onClick={() => {
                    setShowAddPostModal(false);
                    setNewPostText('');
                    setNewPostImage(null);
                    setImagePreview(null);
                  }}
                >
                  Cancel
                </Button>
                <Button type="submit" className="ml-2" disabled={isLoading}>
                  {isLoading ? 'Posting...' : 'Post'}
                </Button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Popup Message Notification - Changed from right to left side */}
      {popupMessage && (
        <div className="fixed bottom-4 left-4 p-4 bg-blue-600 text-white rounded-lg shadow-lg z-50">
          {popupMessage}
          <Button onClick={() => setPopupMessage('')} className="mt-3 bg-blue-600 text-white px-4 py-2 rounded">
            Close
          </Button>
        </div>
      )}
    </div>
  );
};

export default SocialDashboard;