import React, { useState } from 'react';
import LoginPage from './components/LoginPage';
import SignupPage from './components/SignupPage';
import SocialDashboard from './components/SocialDashboard';
import CampusConnect from './components/CampusConnect';
import ProfilePage from './components/ProfilePage';
import './App.css';

function App() {
  const [user, setUser] = useState(null);
  const [showSignup, setShowSignup] = useState(false);
  const [showProfile, setShowProfile] = useState(false);

  const handleLoginSuccess = (userData) => {
    setUser(userData);
  };

  const handleSignupSuccess = (userData) => {
    setUser(userData);
    setShowSignup(false);
  };

  const switchToSignup = () => {
    setShowSignup(true);
  };

  const handleProfileClick = () => {
    setShowProfile(true);
  };

  const handleProfileBack = () => {
    setShowProfile(false);
  };

  return (
    <div className="App">
      {!user && !showSignup && (
        <LoginPage 
          onLoginSuccess={handleLoginSuccess} 
          onSwitchToSignup={switchToSignup} 
        />
      )}
      {showSignup && <SignupPage onSignupSuccess={handleSignupSuccess} />}
      
      {user && !showProfile && (
        <div style={{ display: 'flex', minHeight: '100vh' }}>
          <div style={{ flex: 1, overflowY: 'auto' }}>
            {/* Pass handleProfileClick to SocialDashboard so that its header profile icon can call it */}
            <SocialDashboard user={user} onProfileClick={handleProfileClick} />
          </div>
          <div style={{ width: '300px', borderLeft: '1px solid #e5e7eb', overflowY: 'auto' }}>
            <CampusConnect user={user} />
          </div>
        </div>
      )}
      
      {user && showProfile && (
        <ProfilePage user={user} onBack={handleProfileBack} />
      )}
    </div>
  );
}

export default App;