const express = require('express');
const router = express.Router();
const pool = require('../db'); // your database connection

router.post('/api/create-post', async (req, res) => {
  const { user_email, content, image } = req.body; // image is optional
  try {
    const [result] = await pool.query(
      'INSERT INTO posts (user_email, content, image_url, created_at) VALUES (?, ?, ?, NOW())',
      [user_email, content, image || null]
    );
    res.json({ postId: result.insertId, imageUrl: image || null });
  } catch (error) {
    console.error('Error inserting post:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

module.exports = router;