const express = require('express');
const multer = require('multer');
const path = require('path');
const fs = require('fs');
const mysql = require('mysql2/promise');
const app = express();

// MySQL Connection Pool
let pool;

// Initialize MySQL Connection Pool
async function initializePool() {
  try {
    pool = mysql.createPool({
      host: 'localhost',        // Change this to your MySQL host
      user: 'root',             // Change this to your MySQL username
      password: 'root',     // Change this to your MySQL password
      database: 'campus_connect',   // Change this to your database name
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    
    // Test the connection
    const connection = await pool.getConnection();
    console.log('Successfully connected to MySQL database!');
    connection.release();
    return pool;
  } catch (error) {
    console.error('Failed to connect to MySQL database:', error);
    throw error;
  }
}

// Get the connection pool
function getPool() {
  return pool;
}

// Body parser middleware
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Create an uploads directory if it doesn't exist
const uploadDir = path.join(__dirname, 'uploads');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Configure multer for storing uploaded files
const storage = multer.diskStorage({
  destination: function (req, file, cb) {
    cb(null, uploadDir);
  },
  filename: function (req, file, cb) {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    const ext = path.extname(file.originalname);
    cb(null, file.fieldname + '-' + uniqueSuffix + ext);
  }
});

// File filter to only allow image files
const fileFilter = (req, file, cb) => {
  if (file.mimetype.startsWith('image/')) {
    cb(null, true);
  } else {
    cb(new Error('Not an image! Please upload only images.'), false);
  }
};

const upload = multer({ 
  storage: storage,
  limits: {
    fileSize: 5 * 1024 * 1024 // limit file size to 5MB
  },
  fileFilter: fileFilter
});

// Serve the uploaded files
// Serve the uploaded files
app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

// Image upload endpoint
app.post('/api/upload-image', upload.single('image'), (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ message: 'No image file provided' });
    }
    
    const imageUrl = `/uploads/${req.file.filename}`;
    res.status(200).json({ imageUrl });
  } catch (error) {
    console.error('Error uploading image:', error);
    res.status(500).json({ message: 'Error uploading image' });
  }
});

// User Registration Endpoint
app.post('/api/register', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { name, email, password, year_of_study, department, bio } = req.body;
    
    if (!name || !email || !password || !year_of_study || !department) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    // Check if user already exists
    const [existingUsers] = await pool.query(
      'SELECT * FROM users WHERE email = ?',
      [email]
    );
    
    if (existingUsers.length > 0) {
      return res.status(409).json({ message: 'User with this email already exists' });
    }
    
    // Insert new user
    const [result] = await pool.query(
      'INSERT INTO users (name, email, password_hash, year_of_study, department, bio, created_at, updated_at) VALUES (?, ?, ?, ?, ?, ?, NOW(), NOW())',
      [name, email, password, year_of_study, department, bio || null]
    );
    
    res.status(201).json({ 
      message: 'User registered successfully',
      userId: result.insertId
    });
  } catch (error) {
    console.error('Error registering user:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Fetch all posts
// In server.js, make sure the posts endpoint formats dates properly
// In server.js, make sure the posts endpoint formats dates properly
app.get('/api/posts', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    let query = `
      SELECT p.*, u.name as author_name 
      FROM posts p 
      JOIN users u ON p.user_email = u.email 
    `;
    
    const queryParams = [];
    
    if (req.query.user_id) {
      query += ` WHERE u.id = ? `;
      queryParams.push(req.query.user_id);
    }
    
    query += ` ORDER BY p.created_at DESC LIMIT 50`;
    
    const [rows] = await pool.query(query, queryParams);
    
    // Add more console logging to debug image URLs
    console.log("Raw post data from database:", rows);
    
    const posts = rows.map(post => {
      let imageUrl = post.image_url;
      
      // Debug log each post's image URL
      if (imageUrl && !imageUrl.startsWith('/') && !imageUrl.startsWith('http')) {
        imageUrl = `/uploads/${path.basename(imageUrl)}`;
      }
      
      return {
        id: post.id,
        author: post.author_name,
        content: post.content,
        imageUrl: imageUrl, // Ensure consistent naming and proper path
        timestamp: formatTimestamp(post.created_at),
        likes: 0, // You can add a likes table later
        comments: 0, // You can add a comments count later
        liked: false
      };
    });
    
    console.log("Processed posts being sent to frontend:", posts);
    res.json(posts);
  } catch (error) {
    console.error('Error fetching posts:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Create a new post
app.post('/api/create-post', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { user_email, content, image } = req.body;
    
    // Log what's being received
    console.log("Creating post with image URL:", image);
    
    if (!user_email || !content) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    const [result] = await pool.query(
      'INSERT INTO posts (user_email, content, image_url, created_at) VALUES (?, ?, ?, NOW())',
      [user_email, content, image]
    );
    
    res.status(201).json({ 
      postId: result.insertId,
      message: 'Post created successfully',
      imageUrl: image 
    });
  } catch (error) {
    console.error('Error creating post:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Fetch a single user by ID
app.get('/api/users/:userId', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const userId = req.params.userId;
    
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE id = ?',
      [userId]
    );
    
    if (rows.length === 0) {
      return res.status(404).json({ message: 'User not found' });
    }
    
    const user = rows[0];
    
    const [friendsCount] = await pool.query(
      'SELECT COUNT(*) as count FROM friends WHERE user_id = ? OR friend_id = ?',
      [userId, userId]
    );
    
    const [commentsCount] = await pool.query(
      'SELECT COUNT(*) as count FROM comments WHERE user_id = ?',
      [userId]
    );
    
    const [interests] = await pool.query(
      `SELECT interest FROM user_interests WHERE user_id = ?`,
      [userId]
    );
    
    const userDetails = {
      id: user.id,
      name: user.name,
      email: user.email,
      department: user.department,
      year_of_study: user.year_of_study,
      photo_url: user.photo_url,
      bio: user.bio,
      friends: friendsCount[0].count,
      comments: commentsCount[0].count,
      interests: interests.map(item => item.interest)
    };
    
    res.json(userDetails);
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Search for users
app.get('/api/users', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const query = req.query.query;
    
    if (!query) {
      return res.status(400).json({ message: 'Search query is required' });
    }
    
    const [rows] = await pool.query(
      'SELECT * FROM users WHERE name LIKE ?',
      [`%${query}%`]
    );
    
    res.json(rows);
  } catch (error) {
    console.error('Error searching users:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Send a connection request
// In server.js, modify the send-connection-request endpoint:
app.post('/api/send-connection-request', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { sender_id, receiver_id } = req.body;
    
    if (!sender_id || !receiver_id) {
      return res.status(400).json({ message: 'Sender and receiver IDs are required' });
    }
    
    // Update this query to use from_user and to_user
    const [rows] = await pool.query(
      'SELECT * FROM friends WHERE (from_user = ? AND to_user = ?) OR (from_user = ? AND to_user = ?)',
      [sender_id, receiver_id, receiver_id, sender_id]
    );
    
    if (rows.length > 0) {
      return res.status(400).json({ message: 'Connection request already sent or users are already friends' });
    }
    
    // Update this query to use from_user and to_user
    await pool.query(
      'INSERT INTO friends (from_user, to_user, status) VALUES (?, ?, ?)',
      [sender_id, receiver_id, 'pending']
    );
    
    res.status(201).json({ message: 'Connection request sent' });
  } catch (error) {
    console.error('Error sending connection request:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Accept a connection request
// In server.js, modify the accept-connection-request endpoint:
app.post('/api/accept-connection-request', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { sender_id, receiver_id } = req.body;
    
    if (!sender_id || !receiver_id) {
      return res.status(400).json({ message: 'Sender and receiver IDs are required' });
    }
    
    // Update this query to use from_user and to_user
    const [rows] = await pool.query(
      'SELECT * FROM friends WHERE from_user = ? AND to_user = ? AND status = ?',
      [sender_id, receiver_id, 'pending']
    );
    
    if (rows.length === 0) {
      return res.status(400).json({ message: 'No pending connection request found' });
    }
    
    // Update this query to use from_user and to_user
    await pool.query(
      'UPDATE friends SET status = ? WHERE from_user = ? AND to_user = ?',
      ['accepted', sender_id, receiver_id]
    );
    
    res.status(200).json({ message: 'Connection request accepted' });
  } catch (error) {
    console.error('Error accepting connection request:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Fetch pending connection requests
// In server.js, modify the connection-requests endpoint:
app.get('/api/connection-requests', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const userId = req.query.user_id;
    
    if (!userId) {
      return res.status(400).json({ message: 'User ID is required' });
    }
    
    // Update this query to use from_user and to_user
    const [rows] = await pool.query(`
      SELECT f.id, f.from_user as sender_id, u.name as sender_name, 
             u.department as sender_department, f.created_at
      FROM friends f
      JOIN users u ON f.from_user = u.id
      WHERE f.to_user = ? AND f.status = 'pending'
      ORDER BY f.created_at DESC
    `, [userId]);
    
    res.json(rows);
  } catch (error) {
    console.error('Error fetching connection requests:', error);
    res.status(500).json({ message: 'Server error' });
  }
});
// Create a new event
app.post('/api/events', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { name, date, location } = req.body;
    
    if (!name || !date || !location) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    const [result] = await pool.query(
      'INSERT INTO events (name, date, location, participants, current_participants, created_at) VALUES (?, ?, ?, ?, ?, NOW())',
      [name, date, location, 0, 0]
    );
    
    res.status(201).json({ 
      message: 'Event created successfully',
      eventId: result.insertId
    });
  } catch (error) {
    console.error('Error creating event:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Fetch all events
app.get('/api/events', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const [rows] = await pool.query(
      'SELECT * FROM events ORDER BY date ASC'
    );
    
    res.json(rows);
  } catch (error) {
    console.error('Error fetching events:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Join an event
app.post('/api/join-event', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { user_email, event_id } = req.body;
    
    if (!user_email || !event_id) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    // Check if the event exists
    const [events] = await pool.query(
      'SELECT * FROM events WHERE id = ?',
      [event_id]
    );
    
    if (events.length === 0) {
      return res.status(404).json({ message: 'Event not found' });
    }
    
    const event = events[0];
    
    // Check if user already joined this event
    const [participants] = await pool.query(
      'SELECT * FROM event_participants WHERE user_email = ? AND event_id = ?',
      [user_email, event_id]
    );
    
    if (participants.length > 0) {
      return res.status(400).json({ message: 'User already joined this event' });
    }
    
    // Add user to event participants
    await pool.query(
      'INSERT INTO event_participants (user_email, event_id, event_name, event_date, joined_at) VALUES (?, ?, ?, ?, NOW())',
      [user_email, event_id, event.name, event.date]
    );
    
    // Update event participants count
    await pool.query(
      'UPDATE events SET current_participants = current_participants + 1 WHERE id = ?',
      [event_id]
    );
    
    res.status(200).json({ message: 'Successfully joined the event' });
  } catch (error) {
    console.error('Error joining event:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Get events joined by a user
app.get('/api/user-events', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const userEmail = req.query.email;
    
    if (!userEmail) {
      return res.status(400).json({ message: 'User email is required' });
    }
    
    const [rows] = await pool.query(
      'SELECT ep.*, e.location FROM event_participants ep JOIN events e ON ep.event_id = e.id WHERE ep.user_email = ? ORDER BY ep.event_date ASC',
      [userEmail]
    );
    
    res.json(rows);
  } catch (error) {
    console.error('Error fetching user events:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Leave an event
app.post('/api/leave-event', async (req, res) => {
  try {
    if (!pool) {
      return res.status(500).json({ message: 'Database connection not available' });
    }
    
    const { user_email, event_id } = req.body;
    
    if (!user_email || !event_id) {
      return res.status(400).json({ message: 'Missing required fields' });
    }
    
    // Check if user is in this event
    const [participants] = await pool.query(
      'SELECT * FROM event_participants WHERE user_email = ? AND event_id = ?',
      [user_email, event_id]
    );
    
    if (participants.length === 0) {
      return res.status(400).json({ message: 'User is not part of this event' });
    }
    
    // Remove user from event participants
    await pool.query(
      'DELETE FROM event_participants WHERE user_email = ? AND event_id = ?',
      [user_email, event_id]
    );
    
    // Update event participants count
    await pool.query(
      'UPDATE events SET current_participants = current_participants - 1 WHERE id = ?',
      [event_id]
    );
    
    res.status(200).json({ message: 'Successfully left the event' });
  } catch (error) {
    console.error('Error leaving event:', error);
    res.status(500).json({ message: 'Server error' });
  }
});

// Helper function to format timestamps
function formatTimestamp(timestamp) {
  const date = new Date(timestamp);
  const now = new Date();
  const diffMs = now - date;
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  
  if (diffSec < 60) {
    return 'Just now';
  } else if (diffMin < 60) {
    return `${diffMin} minute${diffMin !== 1 ? 's' : ''} ago`;
  } else if (diffHour < 24) {
    return `${diffHour} hour${diffHour !== 1 ? 's' : ''} ago`;
  } else if (diffDay < 7) {
    return `${diffDay} day${diffDay !== 1 ? 's' : ''} ago`;
  } else {
    return date.toLocaleDateString();
  }
}

// Test route
app.get('/test', (req, res) => {
  res.send('Server is working fine!');
});

// Login endpoint
app.post('/api/login', async (req, res) => {
  const { email, password } = req.body;
  console.log("Login request received:", email);

  try {
    if (!pool) {
      console.error("Database connection failed");
      return res.status(500).json({ message: "Database connection not available" });
    }
    
    console.log("Database connection successful");

    // Fetch user from database
    const [users] = await pool.query("SELECT * FROM users WHERE email = ?", [email]);
    console.log("Database query result:", users);  // Debugging line

    if (users.length === 0) {
      console.log("User not found in database.");
      return res.status(401).json({ message: "User not found" });
    }

    const user = users[0];
    console.log("Stored Password Hash:", user.password_hash, "Entered Password:", password); // Updated log

    // Compare passwords with the correct column name
    if (user.password_hash !== password) {
      console.log("Password mismatch.");
      return res.status(401).json({ message: "Incorrect password" });
    }

    console.log("Login successful for:", user.email);
    res.status(200).json({ 
      message: "Login successful", 
      user: { 
        id: user.id, 
        name: user.name, 
        email: user.email 
      } 
    });

  } catch (error) {
    console.error("Error during login:", error);
    res.status(500).json({ message: "Server error" });
  }
});

// Start the server
async function startServer() {
  try {
    // Initialize the database connection
    await initializePool();
    
    // Start the server
    const PORT = process.env.PORT || 5000;
    app.listen(PORT, () => {
      console.log(`Server running on port ${PORT}`);
    });
  } catch (err) {
    console.error('Failed to start server:', err);
    process.exit(1); // Exit the process if database connection fails
  }
}

// Start the server
startServer();