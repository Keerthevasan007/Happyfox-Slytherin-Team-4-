require('dotenv').config(); // Load environment variables
const mysql = require('mysql2/promise'); // Use promise-based MySQL

let pool;

async function initializePool() {
  try {
    pool = mysql.createPool({
      host: process.env.DB_HOST || 'localhost',
      user: process.env.DB_USER || 'root',
      password: process.env.DB_PASSWORD || 'root',
      database: process.env.DB_NAME || 'campus_connect',
      port: process.env.DB_PORT || 3306,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0
    });
    
    // Test the connection
    const connection = await pool.getConnection();
    console.log("Connected to MySQL database.");
    connection.release();
    
    return pool;
  } catch (err) {
    console.error("Database connection failed!");
    console.error("Error Code:", err.code);
    console.error("Error Message:", err.message);
    throw err;  // Re-throw to handle it in server.js
  }
}

// Export both the pool and the initialization function
module.exports = {
  getPool: () => pool,
  initializePool
};