const express = require('express');
const http = require('http');
const socketIo = require('socket.io');
const cors = require('cors');
require('dotenv').config();

const chatRoutes = require('./routes/chatRoutes'); // Ensure the correct path

const app = express();
const server = http.createServer(app);
const io = socketIo(server, { cors: { origin: '*' } });

app.use(cors());
app.use(express.json());
app.use('/api/chat', chatRoutes);

// ✅ Ensure that './sockets/chatSocket' exports a function
const chatSocket = require('./sockets/chatSocket');
if (typeof chatSocket === 'function') {
    chatSocket(io);
} else {
    console.error('❌ Error: chatSocket is not a function. Check sockets/chatSocket.js.');
}

const PORT = process.env.PORT || 5001;
server.listen(PORT, () => console.log(`🚀 Server running on port ${PORT}`));
