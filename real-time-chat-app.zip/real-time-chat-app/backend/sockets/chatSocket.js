const mysql = require('mysql2/promise');
const redis = require('redis');
require('dotenv').config();

// MySQL Connection Pool
const pool = mysql.createPool({
    host: process.env.MYSQL_HOST,
    user: process.env.MYSQL_USER,
    password: process.env.MYSQL_PASSWORD,
    database: process.env.MYSQL_DATABASE,
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Redis Client with Error Handling
const redisClient = redis.createClient({
    socket: { host: process.env.REDIS_HOST, port: process.env.REDIS_PORT }
});

redisClient.connect().catch(console.error);
redisClient.on('error', (err) => console.error('❌ Redis Error:', err));

module.exports = (io) => {
    io.on('connection', async (socket) => {
        console.log('🟢 New client connected:', socket.id);

        // Fetch previous messages from Redis or MySQL
        const cachedMessages = await redisClient.get('messages');
        if (cachedMessages) {
            socket.emit('previousMessages', JSON.parse(cachedMessages));
        } else {
            try {
                const [rows] = await pool.query('SELECT sender, message, timestamp FROM messages ORDER BY timestamp DESC LIMIT 50');
                socket.emit('previousMessages', rows.reverse());
            } catch (err) {
                console.error('❌ MySQL Fetch Error:', err);
            }
        }

        socket.on('sendMessage', async ({ sender, message }) => {
            if (!sender || !message) return;

            const query = 'INSERT INTO messages (sender, message) VALUES (?, ?)';
            try {
                const conn = await pool.getConnection();
                await conn.execute(query, [sender, message]);
                conn.release();

                const newMessage = { sender, message, timestamp: new Date() };
                io.emit('message', newMessage);

                // Update Redis Cache
                let messages = await redisClient.get('messages');
                messages = messages ? JSON.parse(messages) : [];
                messages.unshift(newMessage);
                if (messages.length > 50) messages.pop();
                await redisClient.set('messages', JSON.stringify(messages), { EX: 86400 }); // 24 hours
            } catch (err) {
                console.error('❌ MySQL Insert Error:', err);
            }
        });

        socket.on('disconnect', () => console.log('🔴 Client disconnected:', socket.id));
    });
};

