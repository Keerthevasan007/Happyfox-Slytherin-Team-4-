const express = require('express');
const router = express.Router();
const pool = require('../config/db'); // Adjust path if necessary

// Get all messages
router.get('/messages', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM messages ORDER BY timestamp DESC');
        res.json(rows);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Database query failed' });
    }
});

// Send a new message
router.post('/messages', async (req, res) => {
    const { user, text } = req.body;
    try {
        const [result] = await pool.query('INSERT INTO messages (user, text) VALUES (?, ?)', [user, text]);
        res.status(201).json({ id: result.insertId, user, text });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Database insert failed' });
    }
});

module.exports = router;
