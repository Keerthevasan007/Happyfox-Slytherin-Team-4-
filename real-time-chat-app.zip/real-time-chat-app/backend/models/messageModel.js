const db = require('../config/db');

const saveMessage = async (sender_id, room, message) => {
    try {
        await db.execute('INSERT INTO messages (sender_id, room, message) VALUES (?, ?, ?)', [sender_id, room, message]);
    } catch (error) {
        console.error('❌ Database Error:', error);
    }
};

const getMessages = async (room) => {
    try {
        const [rows] = await db.execute('SELECT * FROM messages WHERE room = ? ORDER BY timestamp', [room]);
        return rows;
    } catch (error) {
        console.error('❌ Database Error:', error);
        return [];
    }
};

module.exports = { saveMessage, getMessages };
